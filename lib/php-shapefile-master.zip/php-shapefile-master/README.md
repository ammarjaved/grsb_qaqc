# PHP ShapeFile

PHP library to read and write ESRI Shapefiles, compatible with WKT and GeoJSON

---

Documentation and examples at [https://gasparesganga.com/labs/php-shapefile/](https://gasparesganga.com/labs/php-shapefile/)
